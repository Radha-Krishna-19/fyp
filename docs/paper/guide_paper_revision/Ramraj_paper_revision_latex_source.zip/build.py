import re,sys
src=open('rev.src').read()
PRE=r'''\documentclass[10pt,twocolumn,letterpaper]{article}
\usepackage[letterpaper,top=0.75in,bottom=0.85in,left=0.7in,right=0.7in,columnsep=0.25in]{geometry}
\usepackage{mathptmx}\usepackage[T1]{fontenc}\usepackage{amsmath,amssymb}\usepackage{graphicx}\usepackage{xcolor}\usepackage{cite}
\usepackage[small,sc,center]{titlesec}
\renewcommand\thesection{\Roman{section}}\renewcommand\thesubsection{\Alph{subsection}}
\titleformat{\section}{\centering\small\scshape}{\thesection.}{0.5em}{\MakeUppercase}
\titleformat{\subsection}{\itshape\small}{\thesubsection.}{0.5em}{}
\titlespacing*{\section}{0pt}{1.2ex plus .3ex}{0.8ex}\titlespacing*{\subsection}{0pt}{1ex plus .3ex}{0.5ex}
\setlength{\parindent}{1em}\setlength{\parskip}{0pt}\pagestyle{plain}
\renewenvironment{abstract}{\par\small\bfseries\noindent}{\par\medskip}
\setlength{\fboxsep}{0pt}
\definecolor{hlred}{RGB}{255,140,140}\definecolor{hlgrn}{RGB}{140,235,140}
\newcommand{\HLt}[2]{\colorbox{#1}{\strut #2}}
\newcommand{\HLg}[1]{{\color{#1}\leaders\hrule height\ht\strutbox depth\dp\strutbox\hskip 0.28em plus 0.14em minus 0.04em}}
'''
BAN=r'''\fbox{\parbox{0.9\textwidth}{\small\centering \textbf{REDLINE VERSION.} \HLt{hlred}{~red highlight = text removed~}\ \ \HLt{hlgrn}{~green highlight = text added~}\ \ Unmarked text is the original. A clean version with all changes accepted is provided separately.}}
'''
def tokens(t):
    out=[];cur='';depth=0;m=False
    for ch in t:
        if ch=='$': m=not m
        if ch=='{': depth+=1
        if ch=='}': depth-=1
        if ch.isspace() and depth==0 and not m:
            if cur: out.append(cur);cur=''
        else: cur+=ch
    if cur: out.append(cur)
    return out
def hl(text,col):
    text=text.replace('\\ ','~')
    paras=re.split(r'\n\s*\n',text.strip())
    res=[]
    for p in paras:
        tk=tokens(p.replace('\n',' '))
        res.append(('\\HLg{%s}'%col).join('\\HLt{%s}{%s}'%(col,t) for t in tk))
    return '\n\n'.join(res)
def make(mode):
    def addf(m): return hl(m.group(1),'hlgrn') if mode=='red' else m.group(1).strip()
    def delf(m): return hl(m.group(1),'hlred') if mode=='red' else ''
    s0=src.replace('-]][[+','-]]@@SP@@[[+') if mode=='red' else src
    s=re.sub(r'\[\[\+(.*?)\+\]\]',addf,s0,flags=re.S)
    s=re.sub(r'\[\[-(.*?)-\]\]',delf,s,flags=re.S)
    body=s.replace('@@SP@@','\\hspace{0.3em}')
    # banner after maketitle for redline
    if mode=='red': body=body.replace('\\date{}','\\date{\\vspace{1ex}'+BAN.strip()+'}',1)
    return PRE+'\\begin{document}\n'+body+'\n\\end{document}\n'
open('redline.tex','w').write(make('red')); open('clean.tex','w').write(make('clean'))
